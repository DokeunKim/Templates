<!-- Robot Control Home -->
<template>
    <div class="form-layout">
    
    </div>
</template>

<script>
//import {getCurrentInstance} from 'vue'
export default {
    name: 'FormLayout',
    data: () => ({
        layoutHeightCount: 100,
        layoutWidthCount: 100,
        layout: Array.from(Array(100), () => new Array(100))
    }),
    mounted(){
        console.log(this.layout);
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
