<template>
  <div class="login">
    
  </div>
</template>

<script>
export default {
  name: 'Login',
  data: () => ({
    })
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.login{
  height: 100%;
  width: 100%;
  position: absolute;
}
</style>
