export default {
    menu:[
        { title: 'Menu 1', routeName: '', subMenuUse:false, params: {}, query: {}},
        { title: 'Menu 2', routeName: '', subMenuUse:true, subMenu: [
            { title: 'Sub Menu 2-1', routeName: '', params: {}, query:{}},
            { title: 'Sub Menu 2-2', routeName: '', params: {}, query:{}},
            { title: 'Sub Menu 2-3', routeName: '', params: {}, query:{}},
            { title: 'Sub Menu 2-4', routeName: '', params: {}, query:{}}
        ], params: {},query: {}},
        { title: 'Menu 3', routeName: '', subMenuUse:true, subMenu: [
            { title: 'Sub Menu 3-1', routeName: '', params: {}, query:{}},
            { title: 'Sub Menu 3-2', routeName: '', params: {}, query:{}},
            { title: 'Sub Menu 3-3', routeName: '', params: {}, query:{}},
            { title: 'Sub Menu 3-4', routeName: '', params: {}, query:{}}
        ], query: {}},{ title: 'Menu 3', routeName: '', subMenuUse:true, subMenu: [
            { title: 'Sub Menu 3-1', routeName: '', params: {}, query:{}},
            { title: 'Sub Menu 3-2', routeName: '', params: {}, query:{}},
            { title: 'Sub Menu 3-3', routeName: '', params: {}, query:{}},
            { title: 'Sub Menu 3-4', routeName: '', params: {}, query:{}}
        ], query: {}},{ title: 'Menu 3', routeName: '', subMenuUse:true, subMenu: [
            { title: 'Sub Menu 3-1', routeName: '', params: {}, query:{}},
            { title: 'Sub Menu 3-2', routeName: '', params: {}, query:{}},
            { title: 'Sub Menu 3-3', routeName: '', params: {}, query:{}},
            { title: 'Sub Menu 3-4', routeName: '', params: {}, query:{}}
        ], query: {}},
        { title: 'Menu 4', routeName: '', subMenuUse:false, params: {}, query: {}}
    ],
    subMenuHeight: 30

   
};