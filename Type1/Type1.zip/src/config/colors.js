
export default{
    mainColor: '#c9a063'
}