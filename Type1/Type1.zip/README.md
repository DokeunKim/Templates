# multiple_robot_management

# node-sass dependency
```
관리자 권한으로 cmd 오픈 후에 아래 명령어로 설치 진행
npm install --global windows-build-tools
```

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
